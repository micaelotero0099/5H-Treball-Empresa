# Cinquè Hemisferi — web inicial

Web estàtica responsive per a Cinquè Hemisferi, centre d'estimulació cognitiva. HTML, CSS i JavaScript sense framework ni build step. Idioma inicial: català; hi ha un commutador català/castellà.

## Comprovar-la localment

1. Descomprimeix la carpeta del projecte si has rebut el ZIP.
2. Obre `index.html` amb Chrome, Edge o Firefox. La majoria de funcions es poden revisar sense servidor local.
3. La imatge de l'activitat i la imatge del suport digital es carreguen des d'Unsplash; cal connexió a internet per veure-les.

## Pujar-la a un repositori privat de GitHub

1. A GitHub, crea un repositori nou amb el nom `cinque-hemisferi-web` i marca'l **Private**.
2. Descomprimeix el ZIP i puja tots els fitxers i carpetes de dins (incloent-hi `index.html`, `legal.html` i `assets/`) a l'arrel del repositori.
3. Per ara, no activis GitHub Pages si no vols una pàgina publicada. Un repositori privat protegeix els fitxers dins de GitHub, però no implica que el lloc publicat tingui accés privat.
4. Quan arribi el moment de publicar, triarem una opció d'allotjament segons el nivell de privacitat que necessitis.

## Abans de publicar

- Substituir el correu `info@cinquehemisferi.example`, el telèfon de mostra i els horaris per dades reals.
- Afegir l'adreça exacta, després de confirmar-la, i valorar si cal integrar un mapa.
- Completar les biografies de María Bieg, Mariona Gallostra, Eric Abad, Antonio Sánchez, Micael Otero i Marisa Béjar amb les seves dades reals de formació, funció, experiència i àrees d'interès.
- Afegir fotografies reals de les sales interiors i activitats si disposeu dels permisos necessaris.
- Revisar el text legal i de privacitat; `legal.html` és un marcador, no un text legal definitiu.
- Decidir si es mantenen les dues fotografies il·lustratives externes o se substitueixen per fotografies locals aprovades.
- Revisar els serveis, les referències a NeuronUP i qualsevol afirmació professional abans de fer-la pública.

## Fotografies

Les sis fotografies del personal i la fotografia de façana s'han integrat a `assets/images/` seguint l'ordre indicat. Les dues fotografies d'activitats actuals són il·lustratives i es carreguen des d'Unsplash; no representen persones usuàries del centre.

Crèdits d'imatges il·lustratives:
- Vitaly Gariev, “Seniors enjoying coffee and a puzzle together”, Unsplash License: https://unsplash.com/photos/seniors-enjoying-coffee-and-a-puzzle-together-EvOvokXGUCg
- Centre for Ageing Better, “a woman sitting on the floor looking at a tablet”, Unsplash License/Public Domain: https://unsplash.com/photos/a-woman-sitting-on-the-floor-looking-at-a-tablet-UJHhWwCuuAs

## Estructura

- `index.html`: pàgina principal
- `legal.html`: pàgina legal provisional
- `assets/css/styles.css`: disseny responsive i estils
- `assets/js/main.js`: menú mòbil i canvi d'idioma
- `assets/images/brand/`: referència de marca i emblema
- `assets/images/facade/`: façana
- `assets/images/team/`: retrats dels sis membres de l'equip
